sap.ui.define([
    'tcs/hr/hire/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("tcs.hr.hire.controller.Empty",{
        
    });
});